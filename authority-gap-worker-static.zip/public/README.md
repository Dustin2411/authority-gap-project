# The Authority Gap Project - Quiet Beta

Static Netlify-ready site.

## Deploy
Drag and drop this folder or ZIP into Netlify Drop, or connect the repo.

No build command is required. The site serves from the project root.

## File Map
- index.html
- css/style.css
- js/app.js
- pages/*.html
- data/timeline.csv
- netlify.toml
