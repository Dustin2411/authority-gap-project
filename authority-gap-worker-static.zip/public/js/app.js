async function loadTimeline(){
  const table=document.querySelector('#timeline-table tbody');
  if(!table) return;
  const search=document.querySelector('#timeline-search');
  const status=document.querySelector('#timeline-status');
  let rows=[];
  try{
    const res=await fetch('/data/timeline.csv');
    const text=await res.text();
    rows=parseCSV(text);
  }catch(e){
    table.innerHTML='<tr><td colspan="5">Timeline could not be loaded.</td></tr>';return;
  }
  function render(){
    const q=(search?.value||'').toLowerCase();
    const s=status?.value||'';
    const filtered=rows.filter(r=>{
      const hay=Object.values(r).join(' ').toLowerCase();
      return (!q||hay.includes(q))&&(!s||r.Status===s);
    });
    table.innerHTML=filtered.map(r=>`<tr><td>${esc(r.Date)}</td><td>${esc(r.Event)}</td><td>${esc(r.Source)}</td><td>${esc(r.Rights)}</td><td><span class="status ${esc(r.Status).split(' ')[0]}">${esc(r.Status)}</span></td></tr>`).join('')||'<tr><td colspan="5">No matching entries.</td></tr>';
  }
  search?.addEventListener('input',render);status?.addEventListener('change',render);render();
}
function parseCSV(text){
  const lines=text.trim().split(/\r?\n/); const headers=splitCSV(lines.shift());
  return lines.map(line=>{const values=splitCSV(line); const obj={}; headers.forEach((h,i)=>obj[h]=values[i]||''); return obj;});
}
function splitCSV(line){let out=[],cur='',quote=false;for(let i=0;i<line.length;i++){const c=line[i];if(c==='"'&&line[i+1]==='"'){cur+='"';i++;}else if(c==='"'){quote=!quote;}else if(c===','&&!quote){out.push(cur);cur='';}else cur+=c;}out.push(cur);return out;}
function esc(v){return String(v||'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));}
document.addEventListener('DOMContentLoaded',loadTimeline);
