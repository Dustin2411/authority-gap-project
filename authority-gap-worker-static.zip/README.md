# The Authority Gap Project

Static website deployed through Cloudflare Workers with Assets.

## Cloudflare deploy settings

Use this only if Cloudflare created a Worker instead of a Pages project.

- Build command: leave blank or `echo "static site"`
- Deploy command: `npx wrangler deploy`
- Static assets directory: `public`

The site files live in `/public`.
